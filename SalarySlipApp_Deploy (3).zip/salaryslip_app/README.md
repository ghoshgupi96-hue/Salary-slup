# SalarySlip (Open Source)

A simple, self-hosted Flask app to create and download employee salary slips (PDF).

## Features
- Admin & Employee logins
- Create employees
- Create salary slips per month
- Employees can log in to view and download their slips as PDF
- SQLite database; passwords hashed
- MIT licensed

## Quickstart

```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Default admin credentials (change immediately after first login):
- **Email:** admin@example.com
- **Password:** admin123

## Environment
- Python 3.9+
- No external system dependencies. PDF generated using ReportLab.

## Notes
- This is a minimal starting point. Extend fields, add ESI/PF logic, and configure behind a reverse proxy for production use.
```

