
import os
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, send_file
from flask_login import LoginManager, login_user, logout_user, login_required, current_user, UserMixin
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, DecimalField, IntegerField, SelectField
from wtforms.validators import DataRequired, Email, Length, NumberRange
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.orm import sessionmaker, declarative_base, relationship, scoped_session
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas

# --- Config ---
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "salaryslip.sqlite3")

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-key")
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{DB_PATH}"

# --- DB Setup ---
engine = create_engine(app.config["SQLALCHEMY_DATABASE_URI"], connect_args={"check_same_thread": False})
Session = scoped_session(sessionmaker(bind=engine))
Base = declarative_base()

# --- Models ---
class User(Base, UserMixin):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    role = Column(String, default="employee")  # 'admin' or 'employee'
    password_hash = Column(String, nullable=False)
    employee_code = Column(String, unique=True, nullable=True)  # only for employees

    slips = relationship("Payslip", back_populates="employee", cascade="all, delete")

    def set_password(self, pw):
        self.password_hash = generate_password_hash(pw)

    def check_password(self, pw):
        return check_password_hash(self.password_hash, pw)

class Payslip(Base):
    __tablename__ = "payslips"
    id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    month = Column(String, nullable=False)  # e.g., "2025-08"
    designation = Column(String, default="")
    basic = Column(Float, default=0.0)
    hra = Column(Float, default=0.0)
    allowance = Column(Float, default=0.0)
    deduction = Column(Float, default=0.0)
    gross = Column(Float, default=0.0)
    net = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)

    employee = relationship("User", back_populates="slips")

    __table_args__ = (UniqueConstraint('employee_id', 'month', name='unique_employee_month'),)

Base.metadata.create_all(engine)

# Seed default admin
sess = Session()
if not sess.query(User).filter(User.role=="admin").first():
    admin = User(email="admin@example.com", name="Admin", role="admin")
    admin.set_password("admin123")
    sess.add(admin)
    sess.commit()
sess.close()

# --- Auth ---
login_manager = LoginManager(app)
login_manager.login_view = "login_employee"

@login_manager.user_loader
def load_user(user_id):
    s = Session()
    return s.get(User, int(user_id))

# --- Forms ---
class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")

class EmployeeForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired(), Length(max=100)])
    email = StringField("Email", validators=[DataRequired(), Email()])
    employee_code = StringField("Employee Code", validators=[DataRequired(), Length(max=50)])
    password = PasswordField("Temp Password", validators=[DataRequired(), Length(min=6)])
    submit = SubmitField("Save")

class PayslipForm(FlaskForm):
    employee_id = SelectField("Employee", coerce=int, validators=[DataRequired()])
    month = StringField("Month (YYYY-MM)", validators=[DataRequired(), Length(min=7, max=7)])
    designation = StringField("Designation")
    basic = DecimalField("Basic", validators=[DataRequired(), NumberRange(min=0)], places=2, default=0)
    hra = DecimalField("HRA", validators=[NumberRange(min=0)], places=2, default=0)
    allowance = DecimalField("Allowance", validators=[NumberRange(min=0)], places=2, default=0)
    deduction = DecimalField("Deduction", validators=[NumberRange(min=0)], places=2, default=0)
    submit = SubmitField("Create")

# --- Utility ---
def is_admin():
    return current_user.is_authenticated and current_user.role == "admin"

def money(v):
    return f"₹{v:,.2f}"

def render_payslip_pdf(p):
    # Create a simple A4 payslip
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    width, height = A4
    x_margin = 20 * mm
    y = height - 25 * mm

    c.setFont("Helvetica-Bold", 14)
    c.drawString(x_margin, y, "Salary Slip")
    y -= 10 * mm

    c.setFont("Helvetica", 10)
    c.drawString(x_margin, y, f"Employee: {p.employee.name} ({p.employee.employee_code})")
    y -= 6 * mm
    c.drawString(x_margin, y, f"Email: {p.employee.email}")
    y -= 6 * mm
    c.drawString(x_margin, y, f"Designation: {p.designation or '-'}")
    y -= 6 * mm
    c.drawString(x_margin, y, f"Month: {p.month}")
    y -= 10 * mm

    # Earnings
    c.setFont("Helvetica-Bold", 11)
    c.drawString(x_margin, y, "Earnings")
    y -= 6 * mm
    c.setFont("Helvetica", 10)
    c.drawString(x_margin, y, f"Basic: {money(p.basic)}")
    y -= 6 * mm
    c.drawString(x_margin, y, f"HRA: {money(p.hra)}")
    y -= 6 * mm
    c.drawString(x_margin, y, f"Allowance: {money(p.allowance)}")
    y -= 10 * mm

    # Deductions
    c.setFont("Helvetica-Bold", 11)
    c.drawString(x_margin, y, "Deductions")
    y -= 6 * mm
    c.setFont("Helvetica", 10)
    c.drawString(x_margin, y, f"Deductions: {money(p.deduction)}")
    y -= 10 * mm

    # Totals
    c.setFont("Helvetica-Bold", 11)
    c.drawString(x_margin, y, f"Gross: {money(p.gross)}")
    y -= 6 * mm
    c.drawString(x_margin, y, f"Net Pay: {money(p.net)}")
    y -= 12 * mm

    c.setFont("Helvetica-Oblique", 9)
    c.drawString(x_margin, y, "This is a system-generated document.")
    c.showPage()
    c.save()

    buf.seek(0)
    return buf

# --- Routes ---
@app.route("/")
def home():
    if current_user.is_authenticated:
        if current_user.role == "admin":
            return redirect(url_for("admin_dashboard"))
        else:
            return redirect(url_for("employee_slips"))
    return render_template("home.html")

@app.route("/admin/login", methods=["GET", "POST"])
def login_admin():
    form = LoginForm()
    if form.validate_on_submit():
        s = Session()
        user = s.query(User).filter_by(email=form.email.data.strip().lower()).first()
        if user and user.role == "admin" and user.check_password(form.password.data):
            login_user(user)
            s.close()
            return redirect(url_for("admin_dashboard"))
        s.close()
        flash("Invalid admin credentials", "danger")
    return render_template("login_admin.html", form=form)

@app.route("/employee/login", methods=["GET", "POST"])
def login_employee():
    form = LoginForm()
    if form.validate_on_submit():
        s = Session()
        user = s.query(User).filter_by(email=form.email.data.strip().lower()).first()
        if user and user.role == "employee" and user.check_password(form.password.data):
            login_user(user)
            s.close()
            return redirect(url_for("employee_slips"))
        s.close()
        flash("Invalid employee credentials", "danger")
    return render_template("login_employee.html", form=form)

@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Logged out", "info")
    return redirect(url_for("home"))

# --- Admin area ---
@app.route("/admin")
@login_required
def admin_dashboard():
    if not is_admin():
        return redirect(url_for("home"))
    s = Session()
    emp_count = s.query(User).filter_by(role="employee").count()
    slip_count = s.query(Payslip).count()
    s.close()
    return render_template("admin_dashboard.html", emp_count=emp_count, slip_count=slip_count)

@app.route("/admin/employees")
@login_required
def list_employees():
    if not is_admin(): return redirect(url_for("home"))
    s = Session()
    emps = s.query(User).filter_by(role="employee").all()
    s.close()
    return render_template("employees.html", employees=emps)

@app.route("/admin/employees/new", methods=["GET", "POST"])
@login_required
def create_employee():
    if not is_admin(): return redirect(url_for("home"))
    form = EmployeeForm()
    if form.validate_on_submit():
        s = Session()
        if s.query(User).filter((User.email==form.email.data.strip().lower()) | (User.employee_code==form.employee_code.data.strip())).first():
            flash("Email or Employee Code already exists.", "danger")
            s.close()
            return render_template("create_employee.html", form=form)
        u = User(
            email=form.email.data.strip().lower(),
            name=form.name.data.strip(),
            role="employee",
            employee_code=form.employee_code.data.strip()
        )
        u.set_password(form.password.data)
        s.add(u)
        s.commit()
        s.close()
        flash("Employee created.", "success")
        return redirect(url_for("list_employees"))
    return render_template("create_employee.html", form=form)

@app.route("/admin/payslips/new", methods=["GET", "POST"])
@login_required
def create_payslip():
    if not is_admin(): return redirect(url_for("home"))
    form = PayslipForm()
    s = Session()
    form.employee_id.choices = [(e.id, f"{e.name} ({e.employee_code})") for e in s.query(User).filter_by(role="employee").order_by(User.name).all()]
    if form.validate_on_submit():
        e = s.get(User, form.employee_id.data)
        basic = float(form.basic.data or 0)
        hra = float(form.hra.data or 0)
        allowance = float(form.allowance.data or 0)
        deduction = float(form.deduction.data or 0)
        gross = basic + hra + allowance
        net = gross - deduction
        p = Payslip(
            employee=e,
            month=form.month.data,
            designation=form.designation.data or "",
            basic=basic, hra=hra, allowance=allowance, deduction=deduction,
            gross=gross, net=net
        )
        try:
            s.add(p)
            s.commit()
            flash("Payslip created.", "success")
            return redirect(url_for("admin_dashboard"))
        except Exception as ex:
            s.rollback()
            flash("Payslip for this employee and month already exists.", "danger")
    return render_template("create_payslip.html", form=form)

@app.route("/employee/slips")
@login_required
def employee_slips():
    if current_user.role != "employee" and not is_admin():
        return redirect(url_for("home"))
    s = Session()
    if current_user.role == "employee":
        slips = s.query(Payslip).filter_by(employee_id=current_user.id).order_by(Payslip.created_at.desc()).all()
    else:
        slips = s.query(Payslip).order_by(Payslip.created_at.desc()).all()
    s.close()
    return render_template("employee_slips.html", slips=slips)

@app.route("/slip/<int:slip_id>/download")
@login_required
def download_slip(slip_id):
    s = Session()
    p = s.get(Payslip, slip_id)
    if not p:
        s.close()
        flash("Payslip not found.", "danger")
        return redirect(url_for("employee_slips"))
    # Authorization: employees can only download their own
    if current_user.role == "employee" and p.employee_id != current_user.id:
        s.close()
        flash("Not authorized.", "danger")
        return redirect(url_for("employee_slips"))
    pdf = render_payslip_pdf(p)
    filename = f"Payslip_{p.employee.employee_code}_{p.month}.pdf"
    s.close()
    return send_file(pdf, as_attachment=True, download_name=filename, mimetype="application/pdf")

if __name__ == "__main__":
    app.run(debug=True)
