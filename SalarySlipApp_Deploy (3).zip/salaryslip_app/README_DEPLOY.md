# Deploy Guide

You can deploy this app on **Render** (one-click via blueprint) or **Railway** (with Dockerfile).

## Option A: Render (Recommended)
1. Push this folder to a new GitHub repo.
2. Create a Render account → **New +** → **Blueprint** → connect your repo.
3. Select `render.yaml` at the root.
4. Render will auto-create a web service:
   - Build: `pip install -r requirements.txt && pip install gunicorn`
   - Start: `gunicorn app:app -w 3 -b 0.0.0.0:10000`
5. Render will generate `SECRET_KEY`. You can rotate it under **Environment**.
6. Open the URL Render gives you. Use the admin login to set up employees and slips.

> Note: This app uses SQLite by default. For production, consider a managed PostgreSQL.
> To use Postgres, set `DATABASE_URL` env var in Render to something like:
> `postgresql+psycopg2://USER:PASSWORD@HOST:5432/DB` and update app.py to read from it.

## Option B: Railway (Docker)
1. Push the project to GitHub.
2. Create a Railway project → **Deploy from GitHub** → select your repo.
3. Add environment variable **SECRET_KEY** with a long random string.
4. Railway will build from `Dockerfile` and run `gunicorn app:app` on port 8080.
5. Visit the generated domain.

## Option C: Your own VPS
```bash
# on server
git clone <your-repo-url> salaryslip && cd salaryslip
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt gunicorn
export SECRET_KEY='<random-long-string>'
# (Optional) set DATABASE_URL for PostgreSQL
gunicorn -w 3 -b 0.0.0.0:8080 app:app
# put behind Nginx with a reverse proxy
```

## Security & Production Notes
- Change default admin credentials immediately.
- Use HTTPS (Render/Railway handle it automatically).
- Consider enabling Postgres + daily backups.
- Enable password reset flow and lockouts if exposing to the public internet.
- Rotate `SECRET_KEY` if leaked.
